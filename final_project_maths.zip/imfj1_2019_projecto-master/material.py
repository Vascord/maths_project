from color import *

class Material:
    def __init__(self, color, name = "UnknownMaterial"):
        self.color = color
        self.name = name
        self.line_width = 2

